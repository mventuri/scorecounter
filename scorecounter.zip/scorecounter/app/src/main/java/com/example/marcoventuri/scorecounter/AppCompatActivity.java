package com.example.marcoventuri.scorecounter;

/**
 * Created by marcoventuri on 24/02/18.
 */

class AppCompatActivity {
}
